# _*_ coding:utf-8 _*_

listen = '0.0.0.0'

port = 8888

debug = False

log_file_prefix = './logs/web_ssh.log'

auth = {
    'root': 'dec123'
}

secret = 'zzz'

cmdb_api = 'http://192.168.2.72:8000/cmdb/get/host/info/api/'

delay = 10

