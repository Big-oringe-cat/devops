var jQuery;
var wssh = {};

console.log('1731');
jQuery(function ($) {

    var status = $('#status'),
        btn = $('.btn-primary'),
        style = {};


    function parse_xterm_style() {
        var text = $('.xterm-helpers style').text();
        var arr = text.split('xterm-normal-char{width:');
        style.width = parseFloat(arr[1]);
        arr = text.split('div{height:');
        style.height = parseFloat(arr[1]);
    }


    function current_geometry() {
        if (!style.width || !style.height) {
            parse_xterm_style();
        }

        var cols = parseInt(window.innerWidth / style.width, 10) - 1;
        var rows = parseInt(window.innerHeight / style.height, 10);
        return {'cols': cols, 'rows': rows};
    }


    function resize_term(term, sock) {
        var geometry = current_geometry(),
            cols = geometry.cols,
            rows = geometry.rows;


        if (cols !== term.geometry[0] || rows !== term.geometry[1]) {
            term.resize(cols, rows);
            sock.send(JSON.stringify({'resize': [cols, rows]}));
        }
    }


    function callback(msg) {
        if (msg.status) {
            status.text(msg.status);
            setTimeout(function () {
                btn.prop('disabled', false);
            }, 3000);
            return;
        }
        var ws_url = window.location.href.replace('http', 'ws');
        console.log(ws_url);
        var join = (ws_url[ws_url.length - 1] === '/' ? '' : '/');
        console.log(join);
              
        var url = 'ws://106.120.216.3:8021/'+ 'ws?id=' + msg.id;
        console.log(url);
        var sock = new window.WebSocket(url);

        var encoding = msg.encoding;

        var terminal = document.getElementById('#terminal');

        var term = new window.Terminal({
            cursorBlink: true,
        });

        wssh.sock = sock;
        wssh.term = term;

        term.on('data', function (data) {
            sock.send(JSON.stringify({'data': data}));
        });

        sock.onopen = function () {
            $('.container').hide();
            term.open(terminal, true);
            term.toggleFullscreen(true);
        };

        sock.onmessage = function (msg) {
            var reader = new window.FileReader();
            reader.onloadend = function () {
                var decoder = new window.TextDecoder(encoding);
                var text = decoder.decode(reader.result);
                // console.log(text);
                term.write(text);
                if (!term.resized) {
                    resize_term(term, sock);
                    term.resized = true;
                }
            };

            reader.readAsArrayBuffer(msg.data);
        };

        sock.onerror = function (e) {
            console.log(e);
        };

        sock.onclose = function (e) {
            console.log(e);
            term.destroy();
            wssh.term = undefined;
            wssh.sock = undefined;
            $('.container').show();
            status.text(e.reason);
            btn.prop('disabled', false);
        };
    }

    $("#Happenclik").click(function (event) {
        event.preventDefault();

        var formData = new FormData();

        let obj = {
            hostname: "192.168.2.105",
            port: '22',
            username: 'root',
            filename: '',
            password: "dec123"
        };
        formData.append("hostname", obj.hostname);
        formData.append("port", obj.port);
        formData.append("username", obj.username);
        formData.append("filename", obj.filename);
        formData.append("password", obj.password);

        $.ajax({
            url: 'http://106.120.216.3:8021/',
            type: 'POST',
            data: formData,
            success: callback,
            cache: false,
            contentType: false,
            processData: false
        });
    });





    $(window).resize(function () {
        if (wssh.term && wssh.sock) {
            resize_term(wssh.term, wssh.sock);
        }
    });

});