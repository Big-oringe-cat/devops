# _*_ coding:utf-8 _*_
__author__ = 'Carey <carey@akhack.com>'
from webssh.main import main

if __name__ == '__main__':
    main()
