#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : zhengyongyun
# @Time : 2017/11/17 
import SCFProcess
import SCFProcessId
import SCFProcessLoad
import json
import time
import os
import ConfigParser
import string
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
def getProcessId(params):
    scfProcId = SCFProcessId.get_scf_account_process_id(params)
    return scfProcId
def getProcessLoad(params):
    scfLoad = SCFProcessLoad.get_scf_account_process_load(params) 
    return scfLoad       
def deleteFile():    
    inifilePath = (os.path.join((os.path.split(os.path.realpath(__file__)))[0], 'time.ini'))
    cf = ConfigParser.ConfigParser()
    cf.read(inifilePath);
    interval = string.atoi(cf.get(u'time',u'interval'))
    endTime = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time() - interval * 60))
    currDir = os.path.dirname(os.path.realpath(__file__))
    for root, dirs, files in os.walk(currDir):
        for file in files:
            info = os.path.splitext(file)
            if (info[1] == '.dat'):
                if cmp(info[0], endTime) < 0:
                    os.remove(os.path.join(root, file))
    
   
def writeFile(accountDict, accountLoadDict):
    currDir = os.path.dirname(os.path.realpath(__file__))
    filePath = os.path.join(currDir, time.strftime("%Y%m%d%H%M%S", time.localtime(time.time())) + ".dat")
    
    f = open(filePath, 'w')
    for account in accountDict:
        processList = accountDict[account]
        for process in processList:
            info = processList[process]
            id = info['id']
            load = info['load']
            f.write(account + "/" + process + "=" + id + ":" + str(load))
            f.write(u'\n')
    for accountLoad in accountLoadDict:
        load = accountLoadDict[accountLoad]
        f.write(accountLoad + "=" + str(load))
        f.write(u'\n')
        
    f.close()
            
def getSCFProcInfo(accounts):
    data = json.loads(accounts)
    procs = data['data']
    
    accountDict = {}
    for proc in procs:
        scfProc = proc['{#ACCOUNT_SCF_PROCESS}']
        value = scfProc.split("/")
        params = []
        params.append(value[0])        
        
        temp = value[1].split(':')
        if (len(temp) < 2):
            continue
         
        params.append(temp[0])
        params.append(temp[1])
        procId = getProcessId(params)
        load = getProcessLoad(params)
        processList = {}
        if params[0] in accountDict:
            processList = accountDict.get(params[0])
            processList[value[1]] = {'id':procId, 'load':load}
        else:
            processList[value[1]] = {'id':procId, 'load':load}
            accountDict[params[0]] = processList    
    accountLoadDict = {}
    
    for account in accountDict:
        processList = accountDict.get(account)
        maxLoad = -1
        for process in processList:
            info = processList[process]
            load = info['load']
            if (load > maxLoad) :
                maxLoad = load
        accountLoadDict[account] = maxLoad
    
    writeFile(accountDict, accountLoadDict)
    
if __name__ == "__main__":
    
    deleteFile()
    accounts = SCFProcess.get_scf_all_account_process()
    getSCFProcInfo(accounts)
    
