select count(*) as onlineNum from update_info c where c.imsi like '45431%'  and opid=2
