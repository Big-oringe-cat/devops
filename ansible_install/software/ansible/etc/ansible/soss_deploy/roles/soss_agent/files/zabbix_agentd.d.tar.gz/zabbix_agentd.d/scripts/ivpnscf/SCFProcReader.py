#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : zhengyongyun
# @Time : 2017/11/17 
import time
import os
import ConfigParser
import string
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
def getSCFProcInfo(key, type):
    inifilePath = (os.path.join((os.path.split(os.path.realpath(__file__)))[0], 'time.ini'))
    cf = ConfigParser.ConfigParser()
    cf.read(inifilePath);
    interval = string.atoi(cf.get(u'time',u'interval'))
    starttime = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time() - interval * 60))
    endtime = time.strftime("%Y%m%d%H%M%S", time.localtime(time.time()))
    
    currDir = os.path.dirname(os.path.realpath(__file__))
    latestFile = starttime+".dat"
    for root, dirs, files in os.walk(currDir):
        for file in files:
            info = os.path.splitext(file)
            if (info[1] == '.dat'):
                if cmp(info[0], starttime) >= 0 and cmp(info[0], endtime) <= 0:
                    if (cmp(file,latestFile) >0):
                        latestFile = file
    if (not os.path.exists(os.path.join(currDir,latestFile))):
        return ''
    
    f = open(os.path.join(currDir,latestFile),u'r')
    result = ''
    lines = f.readlines()
    for line in lines:
        content = line.split("=")
        if (cmp(content[0], key) == 0):
            if (cmp(type,u'id') == 0):
                result = content[1].split(":")[0].strip('\n')
                break
            if (cmp(type,u'load')==0):
                result = content[1].split(":")[1].strip('\n').strip('%')
                break
            if (cmp(type,u'maxload')==0):
                result = content[1].strip('\n').strip('%')
                break
    f.close()
    return result
if __name__ == "__main__":
    if len(sys.argv) != 3:
        print 'parameter error'
        sys.exit()
    key = sys.argv[1]
    type = sys.argv[2]
    print getSCFProcInfo(key, type)
    pass
