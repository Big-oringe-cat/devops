#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 14:07
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
import json
def get_scf_all_account_process():
    all_users = SCFUtil.get_ipc_sysusers()
    users_cindir = SCFUtil.get_ipc_account(all_users)
    ret = {}
    data = []
    for i in users_cindir.keys():
        process_list = SCFUtil.get_tcap_account_process(i, users_cindir[i])
        if process_list:
            for item in process_list:
                account = {}
                account['{#ACCOUNT_SCF_PROCESS}'] = i+"/"+item[0]+":"+item[1]
                data.append(account)
    ret['data'] = data
    return json.dumps(ret)
if __name__ == '__main__':
    ret = get_scf_all_account_process()
    print ret
