#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : miaowei
# @Time : 
import commands,sys,re
def line_num():
    line_num = 5
    cmd = "tail -6 /home/ocs/cin/diagw.metric"
    result = commands.getstatusoutput(cmd)
    if result[0] == 0:
        for i in result[1].split('\n'):
            if re.match('^Time .*?',i):
                line_num += 1
    else:
        print "cmd error:" + result[0]
        sys.exit()
    return str(line_num)
def rt_rate(name):
    num = line_num()
    cmd = "tail -"+num+" /home/ocs/cin/diagw.metric|awk '$3 == \"CC\" && $2 == \""+name+"\" {s[$2]+= $4; t[$2]+= $5}END{for(i in s)print i,s[i],t[i]}'"
    result = commands.getstatusoutput(cmd)
    if result[0] == 0:
        for i in result[1].split('\n'):
            list=i.split(' ')
            if int(list[1]) == 0:
                print float(0)
            else:
                print round(float(list[1])/int(list[2])*100,2)
def statusCode():
    num = line_num()
    codeDir = {}
    cmd = "tail -"+num+" /home/ocs/cin/diagw.metric|awk '$3 == \"CC\" {print $2,$6}'"
    result = commands.getstatusoutput(cmd)
    if result[0] == 0:
        for i in result[1].split('\n'):
            list=i.split(' ')
            if list[0] not in codeDir.keys():
                codeDir[list[0]] = {}
                for j in list[1].split('|'):
                    J=j.split(':')
                    if len(J) == 2:
                        if J[0] not in codeDir[list[0]].keys():
                            codeDir[list[0]][J[0]] = int(J[1])
                        else:
                            codeDir[list[0]][J[0]] += int(J[1])
                    else:
                        if J[0] not in codeDir[list[0]].keys():
                            codeDir[list[0]][J[0]] = "null"
            else:
                for j in list[1].split('|'):
                    J=j.split(':')
                    if len(J) == 2:
                        if J[0] not in codeDir[list[0]].keys():
                            codeDir[list[0]][J[0]] = int(J[1])
                        else:
                            codeDir[list[0]][J[0]] += int(J[1])
                    else:
                        if J[0] not in codeDir[list[0]].keys():
                            codeDir[list[0]][J[0]] = "null"
    print "OCS statusCode count"
    #print codeDir
    for i in codeDir.keys():
        for j in codeDir[i].keys():
            print "{0} {1} {2}".format(i,j,codeDir[i][j])
    
def t_stream_control(name):
    num = line_num()
    cmd = "tail -"+num+" /home/ocs/cin/diagw.metric|awk '$3 == \"CC\" && $2 == \""+name+"\" {t[$2]+= $7}END{for(i in t)print t[i]}'"
    result = commands.getstatusoutput(cmd)
    for i in result[1].split('\n'):
        print i        
def e_stream_control(name):
    num = line_num()
    cmd = "tail -"+num+" /home/ocs/cin/diagw.metric|awk '$3 == \"CC\" && $2 == \""+name+"\" {e[$2]+= $8}END{for(i in e)print e[i]}'"
    result = commands.getstatusoutput(cmd)
    for i in result[1].split('\n'):
        print i        
def rto_stream_control(name):
    num = line_num()
    cmd = "tail -"+num+" /home/ocs/cin/diagw.metric|awk '$3 == \"CC\" && $2 == \""+name+"\" {r[$2]+= $9}END{for(i in r)print r[i]}'"
    result = commands.getstatusoutput(cmd)
    for i in result[1].split('\n'):
        print i        
def avg_later(name):
    num = line_num()
    cmd = "tail -"+num+" /home/ocs/cin/diagw.metric|awk '$3 == \"CC\" && $2 == \""+name+"\" {a[$2]+= $(NF-1);b[$2]+= 1}END{for(i in a)print a[i]/b[i]/10}'"
    result = commands.getstatusoutput(cmd)
    for i in result[1].split('\n'):
        print round(float(i)/1000,3)
              
 
if __name__ == "__main__":
    if len(sys.argv) == 3:
        name = sys.argv[1]
        func = sys.argv[2]
        if func == "rt_rate":
            rt_rate(name)
        elif func == "t_stream_control":
            t_stream_control(name)
        elif func == "e_stream_control":
            e_stream_control(name)
        elif func == "rto_stream_control":
            rto_stream_control(name)
        elif func == "avg_later":
            avg_later(name)
        else:
            print "no such function"
    elif len(sys.argv) == 2:
        func = sys.argv[1]
        if func == "statusCode":
            statusCode()
        else:
            print "no such function"
    else:
        print "parameter error"
