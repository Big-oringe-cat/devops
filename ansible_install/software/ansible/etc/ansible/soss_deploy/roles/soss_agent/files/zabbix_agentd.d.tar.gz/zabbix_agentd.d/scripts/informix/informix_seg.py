# -*- coding: UTF-8 -*-
#/usr/bin/python
'''
@author: Administrator
'''
import os
import re
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import StringUtil
user = sys.argv[1]
def parse():
    cmd = "su - %s -c 'onstat -g seg'" % user
    p = os.popen(cmd)
    content = p.read()
    classColIndex = 5
    vsegcount = 0
    table = StringUtil.getMatrix(content, r'^id.*blkfree$', r'^Total:.*')
    for row in table:
        if row[classColIndex] == 'V':
            vsegcount = vsegcount + 1
    print vsegcount
parse()
