#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 14:07
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
def read_crash():
    cindir = SCFUtil.get_cindir(user);
    number= SCFUtil.read_crash(user, cindir);
    return number
if __name__ == '__main__':
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    user = sys.argv[1]
    ret = read_crash()
    print ret
