#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/12 21:25
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
def get_scf_caps(user):
    return float(SCFUtil.get_basic(user).get('CAPS', '0.0'))
if __name__ == '__main__':
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    user = sys.argv[1]
    print get_scf_caps(user)
