#!/bin/env python
# -*- coding: UTF-8 -*-
import os
import re
import sys
import json
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import StringUtil
user = sys.argv[1]
def parse():
    cmd = "su - %s -c 'onstat -d'" % user
    p = os.popen(cmd)
    content = p.read()
    dbSpaceTable = StringUtil.getMatrix(
        content, r'^address.*name$', r'.*active.*maximum$')
    dbSpaceDict = {}
    info = {}
    data = []
    for row in dbSpaceTable:
        name = {}
        name["{#INFORMIX_DBNAME}"] = row[-1]
        data.append(name)
    info["data"] = data
    print json.dumps(info)
parse()
