#!/usr/bin/python
# -*- coding: UTF-8 -*-
'''
@author: liliang
'''
import os,re,sys
user = sys.argv[1]
para= sys.argv[2]
def getResult():
    cmd = "su - %s -c 'onstat -p'" % user
    p = os.popen(cmd)
    x = p.read()
    return x
def getContent(content, rowStartReg,rowEndReg):
    strList = content.split('\n')
    resultList = []
    lineStart = -1
    lineEnd = -1
    lineIndex = 0
    for line in strList:
    
        if re.match(rowStartReg,line.rstrip()):
            lineStart = lineIndex
     
    
        if rowEndReg!="":
            if re.match(rowEndReg, line.rstrip()):
                if lineStart > -1:
                    lineEnd = lineIndex
   
        if lineStart>-1 and lineEnd >-1 :        
            break
        lineIndex = lineIndex + 1
   
    
    if lineEnd == -1:
        lineEnd = len(strList)
        
    for line in strList[lineStart+1:lineEnd]:
        if line !="":
            resultList.append(line.split())
    return resultList
def container(): 
    flag = 0 
    content=getResult()
    strLines = getContent(content, r'^Profile', '')
    dict = {}
    lineIndex = 0
    while lineIndex<len(strLines):
        headLine = strLines[lineIndex]
        valueLine = strLines[lineIndex+1]
        colIndex = 0
        for col in headLine:
            if(col == '%cached' and flag ==0):
               col =  'rcached'
               flag = flag+1
            dict[col] = valueLine[colIndex]
            colIndex = colIndex + 1
        lineIndex = lineIndex + 2    
    
    try:
        if para =='bufzong':
            result= float(dict['bufreads'])+float(dict['bufwrits'])
        elif para =='buffer':
            result= float(dict['bufwaits'])*100/(float(dict['bufreads'])+float(dict['bufwrits']))            
        elif para =='checkpoint':
            result= float(dict['ckpwaits'])*100/float(dict['numckpts'])
        elif para =='lockusedrate':
            result= float(dict['lokwaits'])*100/float(dict['lockreqs'])    
        elif para =='readahead':
            result= float(dict['RA-pgsused'])*100/(float(dict['ixda-RA'])+float(dict['idx-RA'])+float(dict['da-RA']))     
        elif para =='readzong':
            result= float(dict['ixda-RA'])+float(dict['idx-RA'])+float(dict['da-RA'])    
        elif para =='rollbkcommit':
            result= float(dict['rollbk'])*100/float(dict['commit'])
        else:
            result=dict[para]
    except FloatingPointError:
        print "ERR:Mathematical error"
    else:
        print result
  
container()
