#!/usr/bin/python
# -*- coding: UTF-8 -*-
'''
@author: liliang
'''
import os,re,sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util.StringUtil import getDict
user = sys.argv[1]
para = sys.argv[2]
def inputInfo():
    cmd = "su - %s -c 'onstat -l'" % user
    p = os.popen(cmd)
    x = p.read()
    return x
def parse():
    dict ={}
    content = inputInfo()
    dict = getDict(content, r'^Physical.*Logging$', r'.*Logical.*Logging$')
    try:
        if para =='buffersize':
            result= float(dict['pages/io'])*100/float(dict['bufsize'])
        else:
            result=dict[para]
    except FloatingPointError:
        print "ERR:Mathematical error"
    else:
        print result
parse()
