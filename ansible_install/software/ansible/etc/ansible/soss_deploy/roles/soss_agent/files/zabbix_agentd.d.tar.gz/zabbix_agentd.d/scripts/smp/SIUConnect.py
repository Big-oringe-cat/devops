#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 14:07
import sys,re,os
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
def get_scf_users():
        cmd = "su - %s -c 'dbaccess bicc_smp /etc/zabbix/zabbix_agentd.d/scripts/smp/SIUConnect.sql' 2>/dev/null|awk 'NR>=4'" % user
	data = os.popen(cmd).read().strip('\n').split('\n')
        ogoffList = data[4].split(' ')
        ogoff = ogoffList[len(ogoffList)-1] 
        ioffList = data[3].split(' ')
        ioff = ioffList[len(ioffList)-1]
	if ogoff == '0':
		return int(ogoff)
	else:
		return round(int(ioff)/int(ogoff),2)	
if __name__ == '__main__':
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    user = sys.argv[1]
    ret = get_scf_users()
    print ret
