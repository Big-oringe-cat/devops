#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:08
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
def get_list_node(port):
    udpcli = UdpClient.UdpClient(global_host, global_port)
    send_host = global_host  # bind_address['host']
    recv_port = global_port  # bind_address['port']
    cmd = '%s list -exnode' % recv_port
    result = udpcli.send_msg(cmd, send_host, int(port))
    resultList= result.split('\n')[0].strip().split(' ')
    currentNodeNum =int(resultList[1].split(':')[1])
    activeNodeNum = int(resultList[2].split(':')[1])
    if currentNodeNum==activeNodeNum:
        print 'Ok'
    elif currentNodeNum>activeNodeNum:
        print 'Problem'
def get_sip_account_process_load(value):
    """
    :param value: list
    :return:  value
    """
    port = value[2]
    return get_list_node(port)
    pass
if __name__=="__main__":
    """
        odbc_web:sipgw1/sipgw2:12512
        """
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    info = sys.argv[1]
    if '/' in info:
        value = info.split('/')
        if len(value) != 2:
            print('paramter format error')
            sys.exit()
        va = []
        va.append(value[0])
        kk = value[1]
        kkl = kk.split(':')
        va[len(va):len(va)] = kkl
        ret = get_sip_account_process_load(va)
        if ret:
            print ret
   
