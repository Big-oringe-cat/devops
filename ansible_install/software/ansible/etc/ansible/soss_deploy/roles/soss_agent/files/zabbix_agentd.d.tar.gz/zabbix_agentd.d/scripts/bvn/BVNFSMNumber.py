#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:08
import re
import sys
import os
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
def get_st_load(port):
    udpcli = UdpClient.UdpClient(global_host, global_port)
    send_host = global_host  # bind_address['host']
    recv_port = global_port  # bind_address['port']
    cmd = '%s ls' % recv_port
    result = udpcli.send_msg(cmd, send_host, int(port)).split('\n')
    for item in result:
        if 'bvn.c.bin' in item:
             using = int(item.split()[6])
             print using
def get_scf_account_process_port():
    user = SCFUtil.get_bvn_sysusers()
    cmd = "ps -u %s -ef|grep scfsrsvoice |grep -v grep" %(user)
    out = os.popen(cmd).read().strip('\n').split()
    user = out[0]
    process = 'scf'+out[8]
    cmd = "su - %s -c'echo $CINDIR'" %(user)
    out = os.popen(cmd).read().strip('\n')
    cmd = "cat %s/etc/config.managementports|grep %s" %(out,process)
    out = os.popen(cmd).read().strip('\n').split()
    port = out[1]
    return get_st_load(port)
if __name__=="__main__":
    get_scf_account_process_port()
