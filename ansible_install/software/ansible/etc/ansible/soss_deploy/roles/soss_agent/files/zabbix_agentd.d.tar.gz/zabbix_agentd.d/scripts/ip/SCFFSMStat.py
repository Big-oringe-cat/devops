#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/12 21:46
import re
import os
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
def get_scf_maxfsmnumber(user, cindir):
    if not SCFUtil.file_is_exist(user, cindir, 'scfenv'):
        return dict(maxfsmnum=1000)
    cmd = "su - %s -c 'cat -E %s/etc/scfenv'" % (user, cindir)
    out = os.popen(cmd).read().strip('\n')
    fsmnum = 1000
    for i in out.split('$'):
        i = i.strip()
        if not i or re.match('^#.*?', i):
            continue
        if re.match('^\s{0,}MaxFSMNumber\s{1,}.*?\d', i):
            fsmnum = int(i.split()[1])
    return dict(maxfsmnum=fsmnum)
def get_scf_fsmnumberstat(user):
    cindir = SCFUtil.get_cindir(user)
    proc_list = SCFUtil.get_ip_account_process(user, cindir)
    maxfsmnum = get_scf_maxfsmnumber(user, cindir)
    basic = SCFUtil.get_basic(user)
    status = 'ok'
    maxfs = int(maxfsmnum['maxfsmnum'])
    proc_size = len(proc_list)
    ret = maxfs * proc_size * 0.8
    number = int(basic.get('FSMNUMBER', '-1'))
    if number == -1: # problem
        return 'problem'
    if number > ret: # problem
        status = 'problem'
    else:
        status = 'ok'
    return status
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    user = sys.argv[1]
    print get_scf_fsmnumberstat(user)
