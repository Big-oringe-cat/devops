#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:08
import re
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
def get_st_load(port):
    """
    get scf process st load value
    :param port:
    :return:  value
    """
    udpcli = UdpClient.UdpClient(global_host, global_port)
    send_host = global_host  # bind_address['host']
    recv_port = global_port  # bind_address['port']
    cmd = '%s st load' % recv_port
    result = udpcli.send_msg(cmd, send_host, int(port))
    load = '0%'
    for i in result.split('\n'):
        reg = r'%s%s%s' % ('^', port, '\s{1,}\d{1,3}%')
        if re.match(reg, i):
            load = i.split()[1]
        if re.match('^\d{1,3}%', i):
            load = i
    #return dict(load=load)
    return load
def get_scf_account_process_load(value):
    """
    :param value: list
    :return:  value
    """
    port = value[2]
    return get_st_load(port)
    pass
if __name__=="__main__":
    """
        odbc_web:scfSCS01:10101:SCF
        """
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    info = sys.argv[1]
    if '/' in info:
        value = info.split('/')
        if len(value) != 2:
            print('paramter format error')
            sys.exit()
        va = []
        va.append(value[0])
        kk = value[1]
        kkl = kk.split(':')
        va[len(va):len(va)] = kkl
        ret = get_scf_account_process_load(va)
        if ret:
            print ret.strip('%')
    pass
