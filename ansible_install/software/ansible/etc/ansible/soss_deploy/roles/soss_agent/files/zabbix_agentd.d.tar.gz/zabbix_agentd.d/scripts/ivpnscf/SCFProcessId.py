#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 14:33
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
import os
import re
def get_user_name(id):
    cmd = 'grep %s  /etc/passwd' % id
    out = os.popen(cmd).read().strip('\n')
    return out.split(':')[0].strip()
def get_scf_running_process():
    process_dict = {}
    cmd = 'ps -eo pid,s,user,args | grep \"scf\"'
    out = os.popen(cmd).read().strip('\n')
    ret = []
    for i in out.split('\n'):
        proc = {}
        if re.match('.*?grep.*?', i) or re.match('.*?python.*?', i):
            continue
        proc_info = i.split()
        if len(proc_info) == 6:
            proc['pid'] = proc_info[0]
            user_name = proc_info[2]
            if user_name.isdigit():
                user_name = get_user_name(user_name)
            proc['user'] = user_name
            proc['process'] = proc_info[3] + proc_info[4]
        if proc:
            ret.append(proc)
    return ret
def get_scf_account_process_id(value):
    """
    :param value: type list
    :return: pid
    """
    user = value[0]
    process = value[1]
    running_process = get_scf_running_process()
    for i in running_process:
        u = i['user']
        p = i['process']
        if u == user and p == process:
            return i['pid']
        else:
            continue
    else:
        return '0'
    pass
if __name__ == "__main__":
    """
    odbc_web/scfSCS01:10101
    """
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    info = sys.argv[1]
    if '/' in info:
        value = info.split('/')
        if len(value) != 2:
            print('paramter format error')
            sys.exit()
        va = []
        va.append(value[0])
        kk = value[1]
        kkl = kk.split(':')
        va[len(va):len(va)] = kkl
        print get_scf_account_process_id(va)
    pass
