#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:08
import re
import sys
import json
user = sys.argv[1]
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
def get_ipc_port():
    ret = 0
    all_users = SCFUtil.get_ipc_sysusers()
    users_cindir = SCFUtil.get_ipc_account(all_users)
    for i in users_cindir.keys():
        process_list = SCFUtil.get_ipc_account_process(i, users_cindir[i])
        if process_list:
            for item in process_list:
                 port = item[1]
                 ret+= get_st_load(port)
    print ret
def get_st_load(port):
    list ={}
    using = 0
    udpcli = UdpClient.UdpClient(global_host, global_port)
    send_host = global_host  # bind_address['host']
    recv_port = global_port  # bind_address['port']
    cmd = '%s ls' % recv_port
    list = udpcli.send_msg(cmd, send_host, int(port)).split('\n')
    for item in list:
        if user in item:
		using+=int(item.split( )[6])
		
    return using
if __name__=="__main__":
    get_ipc_port()
