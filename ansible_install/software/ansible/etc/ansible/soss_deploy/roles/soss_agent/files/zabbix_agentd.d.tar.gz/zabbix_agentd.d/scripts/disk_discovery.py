#!/usr/bin/env python
import re
import json
#r = r"[s|v]d[a-z]$"
r = "\ssd[a-z]\s|\sxvd[a-z]\s|\svd[a-z]\s|cciss\/c0d[0-9]\\b"
rstr = re.compile(r)
disk_list = []
disk_dict = {}
with open("/proc/partitions") as f:
    for line in f:
        if rstr.search(line):
                disk_list.append({"{#DISK_NAME}":line.split()[-1:][0]})
disk_dict["data"] = disk_list
print json.dumps(disk_dict)
