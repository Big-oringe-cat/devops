#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : miaowei
# @Time : 
import commands,sys,re,json
def line_num():
    line_num = 5
    cmd = "tail -6 /home/ocs/cin/diagw.metric"
    result = commands.getstatusoutput(cmd)
    if result[0] == 0:
        for i in result[1].split('\n'):
            if re.match('^Time .*?',i):
                line_num += 1
    else:
        print "cmd error:" + result[0]
        sys.exit()
    return str(line_num)
def getOCSName():
    OCS_list = []
    data = []
    ret = {}
    num = line_num()
    cmd ="tail -"+num+" /home/ocs/cin/diagw.metric|awk '$3 == \"CC\" {print $2}'|sort -u"
    result = commands.getstatusoutput(cmd)
    if result[0] == 0:
        for i in result[1].split('\n'):
            OCS_list.append(i)
    if OCS_list[0]:
        for i in OCS_list:
            account = {}
            account['{#ACCOUNT_OCS}'] = i
            data.append(account)
    ret['data'] = data
    
    return json.dumps(ret)
if __name__ == "__main__":
    ret = getOCSName()
    print ret
