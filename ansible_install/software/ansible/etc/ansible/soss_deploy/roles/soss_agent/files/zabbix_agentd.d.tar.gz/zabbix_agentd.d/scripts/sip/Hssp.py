#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth miaowei 
# @Time 20180518
import commands
def getProcessNum():
    cmd = "ps -elf|grep HSSP|grep -v grep|awk '{print $4}'"
    result = commands.getstatusoutput(cmd)
    if result[1]:
        print int(result[1])
    else:
        print 0
if __name__ == "__main__":
    getProcessNum()
