#!/usr/bin/python
# -*- coding: UTF-8 -*-
import ConfigParser
import os
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
import Util.StringUtil
import Util.UdpClient
global_host = '0.0.0.0'
global_port = Util.UdpClient.get_available_port()
def getOnLineUser():
    inifilePath = (os.path.join((os.path.split(os.path.realpath(__file__)))[0], 'host.ini'))
    cf = ConfigParser.ConfigParser()
    cf.read(inifilePath);
    sections = cf.sections()
    totalUserCount = 0
    for s in sections:
        ip = cf.get(s, 'ip')
        port = cf.get(s,'port')
        keys = cf.get(s,'key')
        usingCount = getUsingCount(ip, port, keys)
        totalUserCount = totalUserCount + usingCount
    return totalUserCount
    
def getUsingCount(ip, port, keys): 
    udp = Util.UdpClient.UdpClient(global_host, global_port)
    recv_port = global_port
    cmd = '%s ls' % recv_port   
    result = udp.send_msg(cmd, ip, int(port))
    lines = Util.StringUtil.getMatrix(result, r'^\d+.*UPDATETIME', '')
    keyArray = keys.split('#')
    usingCount = 0
    for line in lines:
        for key in keyArray:
            if line[0]==key:
                usingCount = usingCount + int(line[6])
    return usingCount
    
    
if __name__ == "__main__":
    ret = getOnLineUser()
    print ret        
    
