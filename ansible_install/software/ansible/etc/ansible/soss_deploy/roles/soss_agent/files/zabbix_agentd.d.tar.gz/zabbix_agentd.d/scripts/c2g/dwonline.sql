select count(*) as onlineNum from update_info c where c.imsi like '20404%'  and opid=2;
