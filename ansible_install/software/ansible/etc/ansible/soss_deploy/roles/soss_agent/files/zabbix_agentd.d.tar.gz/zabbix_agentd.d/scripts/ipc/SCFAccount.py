#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 9:28
import json
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
def get_scf_users():
    user = SCFUtil.get_ipc_sysusers()
    ret = {}
    data = []
    account = {}
    account["{#ACCOUNT_SCF}"] = user
    data.append(account)
    ret['data'] = data
    print json.dumps(ret)
if __name__ == '__main__':
    get_scf_users()
