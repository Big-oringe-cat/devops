# -*- coding: UTF-8 -*-
#/usr/bin/python
'''
@author: Administrator
'''
import os
import re
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import StringUtil
user = sys.argv[1]
para = sys.argv[2]
def parse(para):
    cmd = "su - %s -c 'onstat -l'" % user
    p = os.popen(cmd)
    content = p.read()
    dict = {}
    logTable = StringUtil.getMatrix(
        content, r'^address.*used$', r'.*active.*total$')
    sizeIndex = 5
    size = 0
    usedIndex = 6
    used = 0
    flagIndex = 2
    bCount = 0
    for row in logTable:
        size = size + int(row[sizeIndex])
        used = used + int(row[usedIndex])
        if (row[flagIndex].find('B') == -1):
            bCount = bCount + 1
    dict['size'] = size
    dict['used'] = used
    dict['usedratio'] = round((float(used) * 100) / float(size), 2)
    dict['unbackuped'] = bCount
    print dict[para]
parse(para)
