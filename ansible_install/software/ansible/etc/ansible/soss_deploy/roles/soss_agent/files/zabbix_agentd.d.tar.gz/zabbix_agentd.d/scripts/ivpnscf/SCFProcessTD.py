#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:08
import re
import sys
import json
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
account = []
def get_scf_all_account_process():
    all_users = SCFUtil.get_all_sysusers()
    users_cindir = SCFUtil.get_account(all_users)
    for i in users_cindir.keys():
        if i in ["fep"]:
           process_list = SCFUtil.get_scf_account_process(i, users_cindir[i])
           if process_list:
              for item in process_list:
                account.append(item[1])
    return account
def get_st_load():
    ret = get_scf_all_account_process()
    receive = 0
    send = 0
    for u in ret:
         udpcli = UdpClient.UdpClient(global_host, global_port)
         send_host = global_host  # bind_address['host']
         recv_port = global_port  # bind_address['port']
         cmd1 =  '%s st cdma -cr' % recv_port
         cmd2 =  '%s st cdma -cs ' % recv_port
         cmd = '%s st cdma' % recv_port
         result = udpcli.send_msg(cmd, send_host, int(u))
         for i in result.split('\n'):
             if re.match('^TDisconnect.*?',i ):
               v1 = int(i.split()[1])
               v2 = int(i.split()[2])
               receive += v1
               send += v2
    try:
         rate = round((float(send)) / float(receive)*100, 2)
    except Exception as e:
         print  float(0)
    else:
         print rate
         result1 = udpcli.send_msg(cmd1, send_host, int(u))
         result2 = udpcli.send_msg(cmd2, send_host, int(u))
if __name__ == '__main__':
    get_st_load()
