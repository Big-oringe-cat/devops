#/usr/bin/python
import os,re,sys
user = sys.argv[1]
para = sys.argv[2]
def inputInfo(str):
    cmd = "su - %s -c 'onstat -'" % user
    p = os.popen(cmd)
    x = p.read()
    list = re.split(r'\s+', x)
    dict = {}
    try:
        if('Version' in x):
            key1 = list.index('Version')
            version = list[key1 + 1]
            dict['version'] = version
        if('On-Line' in x):
            dict['state'] = 'On-Line'
        if('Read-Only' in x):
            dict['state'] = 'On-Line'
        if('Off-Line' in x):
            dict['state'] = 'Off-Line'
        if('Shutdown' in x):
            dict['state'] = 'Shutdown'
        if('Recovery' in x):
            dict['state'] = 'Recovery'
        if('menory not initialized for INFORMIXSERVER' in x):
            dict['state'] = 'Shutdown'
        if('Up' in x):
            key2 = list.index('Up')
            time = list[key2:key2 + 4];
            runtime = time[0] + ' ' + time[1] + ' ' + time[2] + ' ' + time[3]
            dict['runtime'] = runtime
        
    except IndexError:
        print "ERR:list index out of range"
    else:
        print dict[str]
inputInfo(para)
