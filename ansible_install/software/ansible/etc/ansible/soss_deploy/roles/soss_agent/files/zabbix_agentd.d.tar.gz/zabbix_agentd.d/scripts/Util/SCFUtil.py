#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 10:40
import re
import os
import commands
__all__ = [
    "get_all_sysusers"
    "get_ipc_sysusers"
    "get_bvn_sysusers"
    "get_account"
    "get_ipc_account"
    "get_cindir"
    "file_is_exist"
    "read_config_ininit"
    "read_crash"
    "read_config_managementports"
    "read_config_manager"
    "get_basic"
    "get_scf_account_users"
    "get_scf_account_process"
    "get_sip_account_process"
    "get_ipc_account_process"
    "get_ip_account_process"
    "get_isup_account_process"
    "get_vn_account_process"
    "get_tcap_account_process"
]
def get_all_sysusers():
    id_user_dict = {}
    cmd = """cat /etc/passwd|grep -v nologin|grep -v halt|grep -v tss7|grep -v beptest|grep -v feptest|grep -v sync|grep -v shutdown|awk -F":" '{ print $1"|"$3"|"$7 }'"""
    out = os.popen(cmd).read().strip('\n')
    for i in out.split('\n'):
        ret = i.split('|')
        if ret[2]:
            user = ret[0]
            uid = ret[1]
            id_user_dict[uid] = user
          
    return id_user_dict
def get_ipc_sysusers():
    cmd = """ps -ef|grep scfipcontrol|grep -v grep|awk 'NR==1'|awk '{print $1}'"""
    out = os.popen(cmd).read().strip('\n')
   
    return out
def get_bvn_sysusers():
    cmd = """ps -ef|grep dlg|grep -v grep|awk '{print $1}'|head -1"""
    out = os.popen(cmd).read().strip('\n')
    return out
def get_account(user_ids):
    users_path={}
    for i in user_ids.keys():
        cmd = "su - %s -c 'echo %s'" % (user_ids[i], "$CINDIR")
        try:
            status, out = commands.getstatusoutput(cmd)
            if not status and out:
                out = out.strip('\n')
                users_path[user_ids[i]] = out
        except:
            pass
    return users_path
def get_ipc_account(user_ids):
    users_path={}
    cmd = "su - %s -c 'echo %s'|grep -v  unlimited" % (user_ids, "$CINDIR")
    try:
        status, out = commands.getstatusoutput(cmd)
        if not status and out:
           out = out.strip('\n')
           users_path[user_ids] = out
    except:
        pass
    return users_path
def get_cindir(user):
    cmd = "su - %s -c 'echo %s'" % (user, "$CINDIR")
    status, out = commands.getstatusoutput(cmd)
    if not status and out:
        return out
    return ''
def file_is_exist(user, cindir, file_name):
    cmd = "su - %s -c 'ls %s/etc'" % (user, cindir)
    out = os.popen(cmd).read().strip('\n')
    ret = out.split('\n')
    if file_name not in ret:
        return False
    return True
def read_config_ininit(user, cindir):
    cmd = "su - %s -c 'cat -E %s/etc/config.ininit'|grep -v  unlimited" % (user, cindir)
    status, out = commands.getstatusoutput(cmd)
    if status != 0:
        return []
    out = out.strip('\n')
    ret = []
    for i in out.split('$'):
        i = i.strip()
        if not i or re.match('^#.*?', i):
            continue
        ret.append(i)
    return ret
def read_crash(user,cindir,parameter):
    cmd = "su - %s -c 'find %s/crash -name %s.* | wc -l'" % (user,cindir,parameter)
    status, out = commands.getstatusoutput(cmd)
    return out
def read_smp_crash(user, cindir):
    cmd = "su - %s -c 'find %s/flume |grep  [0-9]$ |wc -l'" % (user,cindir)
    status, out = commands.getstatusoutput(cmd)
    return out
def read_config_managementports(user, cindir):
    cmd = "su - %s -c 'cat -E %s/etc/config.managementports'|grep -v  unlimited" % (user, cindir)
    status, out = commands.getstatusoutput(cmd)
    if status != 0:
        return []
    out = out.strip('\n')
    ret = []
    for i in out.split('$'):
        i = i.strip()
        if not i or re.match('^#.*?', i):
            continue
        ret.append(i)
    return ret
def read_config_manager(user, cindir):
    cmd = "su - %s -c 'cat -E %s/etc/config.manager'" % (user, cindir)
    status, out = commands.getstatusoutput(cmd)
    if status != 0:
        return []
    out = out.strip('\n')
    ret=[]
    for i in out.split('$'):
        i = i.strip()
        if not i or re.match('^#.*?', i):
            continue
        ret.append(i)
    return ret
def get_basic(user):
    cmd = "su - %s -c 'inmon stdout'" % user
    status, out = commands.getstatusoutput(cmd)
    if status != 0:
        return {}
    out = out.strip('\n')
    ret_dict = {}
    for i in out.split('\n'):
        i = i.strip()
        if not i:
            continue
        kv = i.split()
        ret_dict[kv[0]] = kv[1]
    return ret_dict
def get_smp_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^SCF_CONTROL_SMPCOMMAND.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 8:
                    process = line_list[3] + line_list[4]
                    process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    return processes_ports_list

def get_diameter_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^SCF_CONTROL_DIAGW*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
                    process = 'diagw'
                    process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    return processes_ports_list




def get_scf_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list :
        for process_ininit_item in ininit_list:
            if re.match('^SCF_CONTROL.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6 and re.match('^.*[0-9]$',line_list[4]):
                    process = line_list[3] + line_list[4]
                    process_list.append(process)
            if re.match('^MAN_POP.*?', process_ininit_item):
                # read config.manager
                manager_list = read_config_manager(user, cindir)
                for item in manager_list:
                    if re.match('^\s{0,}SCDF\s{1,}.*?\d', item):
                        procs_nums = item.split()
                        process_name = procs_nums[1]
                        process_num = procs_nums[2]
                        for i in xrange(int(process_num)):
                            process_list.append('%s%d' % (process_name, i))
    else:
        manager_list = read_config_manager(user, cindir)
        for item in manager_list:
            if re.match('^\s{0,}SCDF\s{1,}.*?\d', item):
                procs_nums = item.split()
                process_name = procs_nums[1]
                process_num = procs_nums[2]
                for i in xrange(int(process_num)):
                    process_list.append('%s%d' % (process_name, i))
    # read config.managementports
    managementports_list = read_config_managementports(user, cindir)
    mp_dict = {}
    for mp in managementports_list:
        mp_list = mp.split()
        k = mp_list[0]
        v = mp_list[1]
        mp_dict[k] = v
    if process_list and mp_dict:
        for i in mp_dict.keys():
            if i in process_list:
                tup_process = tuple([i, mp_dict[i]])
                processes_ports_list.append(tup_process)
    return processes_ports_list

def get_sip_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^SCF_CONTROL_SIPGW*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
                    process = line_list[3]
                    process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    return processes_ports_list
def get_ipc_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^SCF_CONTROL.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
		    if re.match('^scfipcontrol$',line_list[3]):
                    	process = 'scf' + line_list[4]
                    	process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    #process_dict[user] = processes_ports_list
    return processes_ports_list
def get_ip_account_process(user, cindir):
    process_dict= {}
    #for key in user_cindir.keys():
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^SCF_CONTROL.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
                    if line_list[4] == 'msvn':
                        process = line_list[4]
                    else:
                        process = 'scf' + line_list[4]
                    process_list.append(process)
            elif re.match('^TCAP.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
                    process = line_list[3] + line_list[5]
                    process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
        #process_dict[user] = processes_ports_list
    return processes_ports_list
def get_isup_account_process(user, cindir):
    """
    must call get_scf_account_process
    :param user_cindir:  dict
    :return:
    """
    process_dict= {}
    #for key in user_cindir.keys():
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
                if re.match('^SCF_CONTROL_ISUP.*?', process_ininit_item):
                        line_list = process_ininit_item.split()
                        if len(line_list) == 6:
                                process = 'scf' + line_list[4]
                                process_list.append(process)
    # read config.managementports
    managementports_list = read_config_managementports(user, cindir)
    mp_dict = {}
    for mp in managementports_list:
        mp_list = mp.split()
        k = mp_list[0]
        v = mp_list[1]
        mp_dict[k] = v
    if process_list and mp_dict:
        for i in mp_dict.keys():
            if i in process_list:
                tup_process = tuple([i, mp_dict[i]])
                processes_ports_list.append(tup_process)
    #process_dict[user] = processes_ports_list
    return processes_ports_list
def get_vn_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
                if re.match('^SCF_CONTROL_vn.*?', process_ininit_item):
                        line_list = process_ininit_item.split()
                        if len(line_list) == 6:
                                process = 'scf' + line_list[4]
                                process_list.append(process)
    # read config.managementports
    managementports_list = read_config_managementports(user, cindir)
    mp_dict = {}
    for mp in managementports_list:
        mp_list = mp.split()
        k = mp_list[0]
        v = mp_list[1]
        mp_dict[k] = v
    if process_list and mp_dict:
        for i in mp_dict.keys():
            if i in process_list:
                tup_process = tuple([i, mp_dict[i]])
                processes_ports_list.append(tup_process)
    #process_dict[user] = processes_ports_list
    return processes_ports_list
def get_tcap_account_process(user, cindir):
    """
    must call get_scf_account_process
    :param user_cindir:  dict
    :return:
    """
    process_dict= {}
    #for key in user_cindir.keys():
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^TCAP.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
                    process = line_list[3] + line_list[5]
                    process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    return processes_ports_list
def get_winfep_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^SCF_CONTROL_fep.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
                    process = line_list[3] + line_list[4]
                    process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    return processes_ports_list
def get_ansi_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^ANSI.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
                    process = 'ansi' + line_list[5]
                    process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    return processes_ports_list
def get_sccp_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^SCCP.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
                    process = 'sccp' + line_list[5]
                    process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    return processes_ports_list
def get_asp_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^ASP.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
                    process = line_list[3] + line_list[5]
                    process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    return processes_ports_list
def get_mtp3_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    ininit_list = read_config_ininit(user, cindir)
    if ininit_list:
        for process_ininit_item in ininit_list:
            if re.match('^MTP.*?', process_ininit_item):
                line_list = process_ininit_item.split()
                if len(line_list) == 6:
                    process = 'mtp3gateway' + line_list[5]
                    process_list.append(process)
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    return processes_ports_list
	
	
	
def get_vpn_account_process(user, cindir):
    process_dict= {}
    processes_ports_list = []
    process_list = []
    manager_list = read_config_manager(user, cindir)
    if  manager_list:
        for item in manager_list:
            if re.match('^\s{0,}SCDF\s{1,}.*?\d', item):
                 procs_nums = item.split()
                 process_name = procs_nums[1]
                 process_num = procs_nums[2]
                 for i in xrange(int(process_num)):
                     process_list.append('%s%d' % (process_name, i))
        # read config.managementports
        managementports_list = read_config_managementports(user, cindir)
        mp_dict = {}
        for mp in managementports_list:
            mp_list = mp.split()
            k = mp_list[0]
            v = mp_list[1]
            mp_dict[k] = v
        if process_list and mp_dict:
            for i in mp_dict.keys():
                if i in process_list:
                    tup_process = tuple([i, mp_dict[i]])
                    processes_ports_list.append(tup_process)
    return processes_ports_list
	
