#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/9/7 11:50
import telnetlib
import time
import sys
import json
def do_telnet(host, port, name, passwd, cmd):
    tn = telnetlib.Telnet(host, int(port), timeout=10)
    tn.read_until('User:')
    tn.write(name + "\r\n")
    tn.read_until('Password:')
    tn.write(passwd + '\r\n')
    tn.read_until(b'>')
    tn.write(cmd + '\r\n')
    time.sleep(1)
    tn.write('\r\n')
    out = tn.read_until(b'>')
    tn.close()
    return out
def get_slc(content):
    #retlist = getMatrix(content, 'RESULT:', '-BSM1>')
    strList = content.split('RESULT:\r\n')
    if len(strList) >= 2:
        index = 0
        data = {}
        for i in strList:
            if index == 0:
                index += 1
                continue
            info = i.strip('-BSM1>')
            infoList = info.strip('\r\n').split(',')
            linedict={}
            linekey = ''
            count = 0
            for it in infoList:
                kv = it.strip(';').split('=')
                linedict[kv[0].strip()] = kv[1].strip()
                if count ==0:
                    linekey = kv[1].strip()
                if count == 1:
                    linekey = linekey+'-'+kv[1].strip()
                count += 1
            data[linekey] = linedict
            index += 1
    return data
    pass
if __name__ == '__main__':
    cmd_memoryusage = ':watch-memoryusage;'
    cmd_netid = ':display-mtp-network:netid=all;'
    cmd_linkloading = ':display-mtp-linkloading;'
    cmd_cpuusage = ':watch-cpuusage:mode=1;'
    cmd_link_slg = ':display-mtp-link:slg=all;'
    out = do_telnet(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], cmd_link_slg)
    data = get_slc(out)
    ret = {}
    info = []
    for i in data.keys():
        tmp = {}
        tmp["{#IPSINFO}"] = i
        info.append(tmp)
    ret['data'] = info
    print json.dumps(ret)
    pass