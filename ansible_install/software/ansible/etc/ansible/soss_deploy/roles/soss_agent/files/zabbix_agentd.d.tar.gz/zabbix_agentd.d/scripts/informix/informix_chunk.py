#!/bin/env python
# -*- coding: UTF-8 -*-
import os
import sys
user = sys.argv[1]
cmd = "su - %s -c 'onstat -d |grep PD'" % user
p = os.popen(cmd)
content = p.read().strip('\n')
print content
