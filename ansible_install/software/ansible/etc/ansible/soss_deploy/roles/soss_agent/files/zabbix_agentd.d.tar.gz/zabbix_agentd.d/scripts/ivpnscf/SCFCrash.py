#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os,re,sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
user=sys.argv[1]
parameter = sys.argv[2]
def read_crash():
    cindir = SCFUtil.get_cindir(user);
    number= SCFUtil.read_crash(user, cindir, parameter);
    print number;
read_crash()
