select case  when sum(main_num_shortmsg) > 0 then sum(main_num_shortmsg) else 0 end as totalnum from dw_st_b_5minute
where stdate>=to_char(current-interval(5) minute to minute,'%Y%m%d%H%M00') 
and  stdate<=to_char(current minute to minute,'%Y%m%d%H%M59')  and serviceType='dw_qh'
