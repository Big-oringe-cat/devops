#!/usr/bin/python
# -*- coding: UTF-8 -*-
import os,re,sys
para1=sys.argv[1]
para2=sys.argv[2]
def versionnum():
    p = os.popen("cat /etc/redhat-release")
    x = p.read()
    m = re.findall(r'(\w*[0-9]+)\w*', x)[0:1]
    return  m
def parse(para1,para2):
    versionName = versionnum()
    try:
        if versionName == 7 :
                dict={"rrqm":"$2","wrqm":"$3","rps":"$4","wps":"$5","rKBps":"$6","wKBps":"$7","avgrq-sz":"$8","avgqu-sz":"$9","await":"$10","r_await":"$11","w_await":"$12","svctm":"$13","util":"$14"}
                content = os.popen("iostat -dxkt |grep '\\b%s\\b'|tail -1|awk '{print %s}'" %(para1,dict[para2]))
        else:
            dict={"rrqm":"$2","wrqm":"$3","rps":"$4","wps":"$5","rKBps":"$6","wKBps":"$7","avgrq-sz":"$8","avgqu-sz":"$9","await":"$10","svctm":"$11","util":"$12"}
            content = os.popen("iostat -dxkt |grep '\\b%s\\b'|tail -1|awk '{print %s}'" %(para1,dict[para2]))
    except KeyError:
        print "Error:The key was not found"
    else:
        print content.read()
parse(para1,para2)