#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 9:28
import json
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
def get_users():
    user_ids = SCFUtil.get_all_sysusers()
    scf_users = SCFUtil.get_account(user_ids)
    ret = {}
    data = []
    for i in scf_users.keys():
        account = {}
        account["{#ACCOUNT_SCF}"] = i
        data.append(account)
    ret['data'] = data
    print json.dumps(ret)
if __name__ == '__main__':
    get_users()
