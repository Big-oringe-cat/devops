#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:08
import re
import sys
import os
import commands
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
service_type="VPN.bin"
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
account = {}
def get_values(port,key):
    udpcli = UdpClient.UdpClient(global_host, global_port)
    send_host = global_host  # bind_address['host']
    recv_port = global_port  # bind_address['port']
    cmd = '{0} servicest {1}'.format(recv_port,str(key))
    result = udpcli.send_msg(cmd, send_host, int(port))
    print result
    return result.split('\n')
def get_vpn_all_account_process():
    all_users = SCFUtil.get_all_sysusers()
    users_cindir = SCFUtil.get_account(all_users)
    print users_cindir
    dir = {}
    for i in users_cindir.keys():
        if i == 'bep':
            file = users_cindir[i]+"/etc/service.bin"
            if os.path.exists(file):
                print i
                cmd = "cat %s" % file
                status, out = commands.getstatusoutput(cmd)
                if not status and out:
                    for j in out.split('\n'):
                        print j
                        if re.search(' '+service_type+' ',j):
                            key = j.split()[1]
                            process_list = SCFUtil.get_vpn_account_process(i, users_cindir[i])
                            if process_list:
                                port = process_list[0][1]
                                dir[key]=port
    print dir
    return get_values(port,key)
def jtl():
    a=0
    b=0
    c=0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('Con_CutConectCPN1_ForZJ_1', j):
            a += int(j.split(' ')[-1])
        if re.search('Con_ConnectCPN2_ForZJ', j):
            b += int(j.split(' ')[-1])
        if re.search('Ini_Msg1', j):
            c += int(j.split(' ')[-1])
    if c == 0:
        print float(0)
    else:
        connect_sucess_rate = float((a+b)/c*100)
        print connect_sucess_rate
def ydl():
    a=0
    c=0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('AsnEvent_InvokeID', j):
            a += int(j.split(' ')[-1])
        if re.search('Ini_Msg1', j):
            c += int(j.split(' ')[-1])
    if c == 0:
        print float(0)
    else:
        connect_sucess_rate = float(a/c*100)
        print connect_sucess_rate
def sh():
    call_try_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('Ini_Msg1', j):
            call_try_time += int(j.split(' ')[-1])
    print call_try_time
 
 
def jx():
    a=0
    b=0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('Con_CutConectCPN1_ForZJ_1', j):
            a += int(j.split(' ')[-1])
        if re.search('Con_ConnectCPN2_ForZJ', j):
            b += int(j.split(' ')[-1])
    connect_time = a+b
    print connect_time
 
 
def yd():
    answer_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('AsnEvent_InvokeID', j):
            answer_time += int(j.split(' ')[-1])
    print answer_time
 
        
def qd():
    short_num_group_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('oCheckCalledPNP_1', j):
            short_num_group_time += int(j.split(' ')[-1])
    print short_num_group_time
def qc():
    long_num_group_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('teamflag_acrcallflag', j):
            long_num_group_time += int(j.split(' ')[-1])
    print long_num_group_time
def qw():
    a=0
    b=0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('OffCall_CheckOffGroupFunc', j):
            a += int(j.split(' ')[-1])
        if re.search('teamflag_acrcallflag_1', j):
            b += int(j.split(' ')[-1])
    outside_group_time = a + b
    print outside_group_time
if __name__=="__main__":
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    func = sys.argv[1]
    if func == 'jtl':
        jtl()
    elif func == 'ydl':
        ydl()
    elif func == 'sh':
        sh()
    elif func == 'jx':
        jx()
    elif func == 'yd':
        yd()
    elif func == 'qd':
        qd()
    elif func == 'qc':
        qc()
    elif func == 'qw':
        qw()
