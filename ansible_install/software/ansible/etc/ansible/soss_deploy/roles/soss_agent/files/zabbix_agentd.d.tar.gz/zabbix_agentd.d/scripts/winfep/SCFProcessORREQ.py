#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:08
import re
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
def get_st_load(port):
    udpcli = UdpClient.UdpClient(global_host, global_port)
    send_host = global_host  # bind_address['host']
    recv_port = global_port  # bind_address['port']
    cmd1 =  '%s ls -c' % recv_port
    cmd =  '%s ls  1 ' % recv_port
    result = udpcli.send_msg(cmd, send_host, int(port))
    for i in result.split('\n'):
	if re.match('^AvarageTime.*?',i ):
	    ls =round(float(i.split()[1]),2)
	    print ls
    result = udpcli.send_msg(cmd1, send_host, int(port))
def get_scf_account_process_load(value):
    port = value[2]
    return get_st_load(port)
    pass
if __name__=="__main__":
    """
        odbc_web:scfSCS01:10101:SCF
        """
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    info = sys.argv[1]
    if '/' in info:
        value = info.split('/')
        if len(value) != 2:
            print('paramter format error')
            sys.exit()
        va = []
        va.append(value[0])
        kk = value[1]
        kkl = kk.split(':')
        va[len(va):len(va)] = kkl
        ret = get_scf_account_process_load(va)
    pass
