#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2017/8/14 9:28
import json
import sys
import os
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
def get_bvn_users():
    id_user_dict = {}
    user = SCFUtil.get_bvn_sysusers()
    cmd = "ps -u %s -ef|grep scfsrsvoice |grep -v grep" %(user)
    out = os.popen(cmd).read().strip('\n').split()
    print out[1]
if __name__ == '__main__':
    get_bvn_users()
