# -*- coding: UTF-8 -*-
'''
Created on 2017年8月2日
@author: Administrator
'''
import re
def getRegValue(content, reg):
    """获得指定内容中所有匹配正则表达式的内容。
    
             匹配方法为按行匹配
             
    Args:
        content:需要匹配的内容
        reg:正则表达式
    Returns:
                          返回所有符合正则表达式要求的内容的列表
    """
    strList = content.split('\n')
    resultList = []
    for line in strList:
        matchObject = re.match(reg, line, re.I)
        if matchObject:
            resultList.append(matchObject.group())    
    return resultList
'''
'''
def getMatrix(content, rowStartReg, rowEndReg):
    """获得指定内容中的表格，但不包含 表头内容
             
    Args:
        content:需要匹配的内容
        rowStartReg:匹配表头的正则表达式
        rowEndReg:匹配表结束的正则表达式，如果内容中表的结尾为最后一行，可以直接用空字符串表示
    Returns:
                           按行列返回表的内容。
    """
    strList = content.split('\n')
    resultList = []
    lineStart = -1
    lineEnd = -1
    lineIndex = 0
    for line in strList:
    
        if re.match(rowStartReg,line.rstrip()):
            lineStart = lineIndex
     
    
        if rowEndReg!="":
            if re.match(rowEndReg, line.rstrip()):
                if lineStart > -1:
                    lineEnd = lineIndex
   
        if lineStart>-1 and lineEnd >-1 :        
            break
        lineIndex = lineIndex + 1
   
    
    if lineEnd == -1:
        lineEnd = len(strList)
        
    for line in strList[lineStart+1:lineEnd]:
        if line !="":
            resultList.append(line.split())
    return resultList
def getDict(content, rowStartReg, rowEndReg):
    """获得指定内容中的参数值 对
             
    Args:
        content:需要匹配的内容
        rowStartReg:匹配参数块起始的正则表达式
        rowEndReg:匹配参数块结束的正则表达式，如果内容中参数块的结尾为最后一行，可以直接用空字符串表示
    Returns:
                          按DICT返顺键 值对
    """    
    strLines = getMatrix(content, rowStartReg, rowEndReg)
    dict = {}
    lineIndex = 0
    while lineIndex<len(strLines):
        headLine = strLines[lineIndex]
        valueLine = strLines[lineIndex+1]
        colIndex = 0
        for col in headLine:
            dict[col] = valueLine[colIndex]
            colIndex = colIndex + 1
        lineIndex = lineIndex + 2    
         
    return dict   
