# -*- coding: UTF-8 -*-
#/usr/bin/python
import os
import re
import sys
def get_xms_process():
    cmd = "ps -ef|grep xmserver" 
    out = os.popen(cmd).read().strip('\n').split('\n')
    for i in out:
	    if 'xmserver'in i.split( )[7]:
		process_id = i.split( )[1]
                print process_id
      
if __name__=="__main__":
    get_xms_process()
