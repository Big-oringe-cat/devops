select count(*) as totalNum from dw_sub sub where sub.imsib like '45403%'
