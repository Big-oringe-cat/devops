#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/9/7 11:34
import telnetlib
import time
import sys
import re
def getMatrix(content, rowStartReg, rowEndReg):
    """获得指定内容中的表格，但不包含 表头内容
    Args:
        content:需要匹配的内容
        rowStartReg:匹配表头的正则表达式
        rowEndReg:匹配表结束的正则表达式，如果内容中表的结尾为最后一行，可以直接用空字符串表示
    Returns:
                           按行列返回表的内容。
    """
    strList = content.split('\n')
    resultList = []
    lineStart = -1
    lineEnd = -1
    lineIndex = 0
    for line in strList:
        if re.match(rowStartReg, line.rstrip()):
            lineStart = lineIndex
        if rowEndReg != "":
            if re.match(rowEndReg, line.rstrip()):
                if lineStart > -1:
                    lineEnd = lineIndex
        if lineStart > -1 and lineEnd > -1:
            break
        lineIndex = lineIndex + 1
    if lineEnd == -1:
        lineEnd = len(strList)
    for line in strList[lineStart + 1:lineEnd]:
        if line.rstrip('\r') != "":
            resultList.append(line.split())
    return resultList
def do_telnet(host, port, name, passwd, cmd):
    tn = telnetlib.Telnet(host, int(port), timeout=10)
    tn.read_until('User:')
    tn.write(name + "\r\n")
    tn.read_until('Password:')
    tn.write(passwd + '\r\n')
    tn.read_until(b'>')
    tn.write(cmd + '\r\n')
    time.sleep(1)
    tn.write('\r\n')
    out = tn.read_until(b'>')
    tn.close()
    return out
def get_cpuusage(content):
    retlist = getMatrix(content, 'WATCHING', '-BSM1>')
    for i in retlist:
        if i:
            ret = i[0].split('=')
            return ret[1].strip('%')
    pass
if __name__ == '__main__':
    cmd_memoryusage = ':watch-memoryusage;'
    cmd_netid = ':display-mtp-network:netid=all;'
    cmd_linkloading = ':display-mtp-linkloading;'
    cmd_cpuusage = ':watch-cpuusage:mode=1;'
    out = do_telnet(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], cmd_cpuusage)
    print get_cpuusage(out)
    pass