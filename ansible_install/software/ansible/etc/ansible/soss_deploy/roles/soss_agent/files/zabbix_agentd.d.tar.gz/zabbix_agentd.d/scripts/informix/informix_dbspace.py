# -*- coding: UTF-8 -*-
#/usr/bin/python
'''
@author: Administrator
'''
import os
import re
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import StringUtil
user = sys.argv[1]
para = sys.argv[2]
def parse(para):
    cmd =  "su - %s -c 'onstat -d'" % user
    p = os.popen(cmd)
    content = p.read()
    dbSpaceTable = StringUtil.getMatrix(
        content, r'^address.*name$', r'.*active.*maximum$')
    
    result = StringUtil.getMatrix(
        content, r'^address.*pathname$', r'.*active.*maximum$')
  
    chunkTable=[] 
    for item in result:
        if re.match('^(\d|[a-z]).*?\d',item[0]):
           chunkTable.append(item)
    
    dbSpaceDict = {}
    dbSpaceSizeDict = {}
    dbSpaceFreeDict = {}
    dbSpaceUsagedDict = {}
    numberIndex = 1
    nameIndex = -1
    for row in dbSpaceTable:
        dbSpaceDict[row[numberIndex]] = row[nameIndex]
        dbSpaceSizeDict[row[numberIndex]] = 0
        dbSpaceFreeDict[row[numberIndex]] = 0
    dbsIndex = 2
    sizeIndex = 4
    freeIndex = 5
    for row in chunkTable:
        index = row[dbsIndex]
        dbSpaceSizeDict[index] = dbSpaceSizeDict.get(
            index) + int(row[sizeIndex])
        dbSpaceFreeDict[index] = dbSpaceFreeDict.get(
            index) + int(row[freeIndex])
    for dbsIndex in dbSpaceDict.keys():
        if float(dbSpaceSizeDict.get(dbsIndex)) != 0.0:
            dbSpaceUsagedDict[dbSpaceDict[dbsIndex]] = round(float((dbSpaceSizeDict.get(dbsIndex) - dbSpaceFreeDict.get(dbsIndex)) * 100) / float(dbSpaceSizeDict.get(dbsIndex)), 2)
        else:
            dbSpaceUsagedDict[dbSpaceDict[dbsIndex]] = 0
    result = dbSpaceUsagedDict[para]
    print result

parse(para)
