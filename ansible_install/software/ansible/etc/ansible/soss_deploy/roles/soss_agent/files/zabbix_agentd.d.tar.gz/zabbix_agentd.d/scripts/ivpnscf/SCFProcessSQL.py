#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:36
import re
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
def getMaxtrix(content, rowStartReg, rowEndReg):
    strList = content.split('\n')
    resultList = []
    lineStart = -1
    lineEnd = -1
    lineIndex = 0
    for line in strList:
        if re.match(rowStartReg, line.rstrip()):
            lineStart = lineIndex
        if rowEndReg != '':
            if re.match(rowEndReg, line.rstrip()):
                lineEnd = lineIndex
        # if lineStart > -1 and lineEnd >-1:
        #     break
        lineIndex = lineIndex + 1
    if lineEnd == -1:
        lineEnd = len(strList)
    for line in strList[lineStart + 1:lineEnd]:
        if line != '':
            resultList.append(line.split())
    return resultList
def get_scf_accout_mananger(user,cindir):
    process_list = []
    manager_list = SCFUtil.read_config_manager(user, cindir)
    for item in manager_list:
        if re.match('^\s{0,}SCDF\s{1,}.*?\d', item):
            procs_nums = item.split()
            process_name = procs_nums[1]
            process_num = procs_nums[2]
            for i in xrange(int(process_num)):
                process_list.append('%s%d' % (process_name, i))
    return process_list
def get_scf_account_first_process(user, cindir):
    """
    must call get_scf_account_first_process
    :param user_cindir:  dict
    :return:
    """
    process_dict = {}
    # for key in user_cindir.keys():
    processes_ports_list = []
    process_list = []
    ininit_list = SCFUtil.read_config_ininit(user, cindir)
    for process_ininit_item in ininit_list:
        if re.match('^SCF_CONTROL.*?', process_ininit_item):
            line_list = process_ininit_item.split()
            if len(line_list) == 6:
                process = line_list[3] + line_list[4]
                process_list.append(process)
                
        if re.match('^MAN_POP.*?', process_ininit_item):
            # read config.manager
            process_list = get_scf_accout_mananger(user,cindir)
    if  len(process_list)==0:
        process_list = get_scf_accout_mananger(user,cindir)
        
    managementports_list = SCFUtil.read_config_managementports(user, cindir)
    #mp_dict = {}
    first_process = []
    for mp in managementports_list:
        mp_list = mp.split()
        k = mp_list[0]
        v = mp_list[1]
        #mp_dict[k] = v
        if k in process_list:
            first_process = [k, v]
            break
    return first_process
def get_st_sql_udp_str(port):
    return '%s st sql' % port
def get_account_process_stsql(value):
    resultList = []
    maxTime = 0
    tableName = 'null'
    user = value
    cindir = SCFUtil.get_cindir(user)
    first_process = get_scf_account_first_process(user, cindir)
    if len(first_process) != 2:
	resultList.append(tableName)
        resultList.append(maxTime)
        return resultList
    pro_name = first_process[0]
    pro_port = int(first_process[1])
    
    udpcli = UdpClient.UdpClient(global_host, global_port)
   
    result = udpcli.send_msg(get_st_sql_udp_str(
        global_port), global_host, pro_port)
    result_list = getMaxtrix(result, 'TABLENAME.*?', 'total.*?')
    
    for row in result_list:
        if row[2] > maxTime:
            maxTime = row[2]
            tableName = row[0]
    resultList.append(tableName)
    resultList.append(maxTime)
    return resultList
    
if __name__ == "__main__":
    if len(sys.argv) != 3:
        print 'parameter error'
        sys.exit()
    info = sys.argv[1]
    op = sys.argv[2]
  
    ret = get_account_process_stsql(info)
    if op == 'table':
        print ret[0]
    if op == 'avg':
        print ret[1]
