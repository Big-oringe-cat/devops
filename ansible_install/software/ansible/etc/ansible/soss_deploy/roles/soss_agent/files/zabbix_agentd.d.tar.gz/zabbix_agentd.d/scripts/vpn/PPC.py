#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:08
import re
import sys
import os
import commands
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
service_type = "ppc_ocs_win.bin"
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
account = {}
def get_values(port,key):
    udpcli = UdpClient.UdpClient(global_host, global_port)
    send_host = global_host  # bind_address['host']
    recv_port = global_port  # bind_address['port']
    cmd = '{0} servicest {1}'.format(recv_port,str(key))
    result = udpcli.send_msg(cmd, send_host, int(port))
    return result.split('\n')
def get_vpn_all_account_process():
    all_users = SCFUtil.get_all_sysusers()
    users_cindir = SCFUtil.get_account(all_users)
    dir={}
    for i in users_cindir.keys():
        if i == "bep":
            file = users_cindir[i]+"/etc/service.bin"
            if os.path.exists(file):
                cmd = "cat %s" % file
                status, out = commands.getstatusoutput(cmd)
                if not status and out:
                    for j in out.split('\n'):
                        if re.search(' '+service_type+' ',j):
                            key = j.split()[1]
                            process_list = SCFUtil.get_vpn_account_process(i, users_cindir[i])
                            if process_list:
                                port = process_list[0][1]
                                dir[key]=port
    return get_values(port,key)

def jtl():
    a=float(0)
    c=0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('WaitConnect', j):
            a += int(j.split(' ')[-1])
        if re.search('IniMsg', j):
            c += int(j.split(' ')[-1])
    if c == 0:
        print float(0)
    else:
        connect_sucess_rate = "%.2f" %(a/c*100)
        print connect_sucess_rate
def ydl():
    a=float(0)
    c=0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('answer_deltimer', j):
            a += int(j.split(' ')[-1])
        if re.search('IniMsg', j):
            c += int(j.split(' ')[-1])
    if c == 0:
        print float(0)
    else:
        connect_sucess_rate = "%.2f" %(a/c*100)
        print connect_sucess_rate
def MOsh():
    MO_try_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('getOrreqPara', j):
            MO_try_time += int(j.split(' ')[-1])
    print MO_try_time
def MTsh():
    MT_try_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('getAnlyzdPara', j):
            MT_try_time += int(j.split(' ')[-1])
    print MT_try_time
def MOjx():
    MO_connect_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('oAnlyzdSend', j):
            MO_connect_time += int(j.split(' ')[-1])
    print MO_connect_time
def MTjx():
    MT_connect_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('t_Anlyd2_send', j):
            MT_connect_time += int(j.split(' ')[-1])
    print MT_connect_time
def MOyd():
    MO_connect_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('answer_o_cellid', j):
            MO_connect_time += int(j.split(' ')[-1])
    print MO_connect_time
def MTyd():
    MT_connect_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('answer_t_cellid', j):
            MT_connect_time += int(j.split(' ')[-1])
    print MT_connect_time
def mf():
    free_call_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('answer_t_cellid', j):
            free_call_time += int(j.split(' ')[-1])
    print free_call_time
    
def lx():
    a=0
    b=0
    c=0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('CCA_TimeOut', j):
            a += int(j.split(' ')[-1])
        if re.search('CCA_UpdateLog', j):
            b += int(j.split(' ')[-1])
        if re.search('CCA_TermLog', j):
            c += int(j.split(' ')[-1])
    offline_time = a + b + c
    print offline_time

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    func = sys.argv[1]

    if func == 'jtl':
        jtl()
    elif func == 'ydl':
        ydl()
    elif func == 'MOsh':
        MOsh()
    elif func == 'MTsh':
        MTsh()
    elif func == 'MOjx':
        MOjx()
    elif func == 'MTjx':
        MTjx()
    elif func == 'MOyd':
        MOyd()
    elif func == 'MTyd':
        MTyd()
    elif func == 'mf':
        mf()
    elif func == 'lx':
        lx()
