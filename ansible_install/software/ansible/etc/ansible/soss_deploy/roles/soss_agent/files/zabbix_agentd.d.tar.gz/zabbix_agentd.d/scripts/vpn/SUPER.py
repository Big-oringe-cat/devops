#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:08
import re
import sys
import os
import commands
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
service_type="supper_tel.bin"
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
account = {}
def get_values(port,key):
    udpcli = UdpClient.UdpClient(global_host, global_port)
    send_host = global_host  # bind_address['host']
    recv_port = global_port  # bind_address['port']
    cmd = '{0} servicest {1}'.format(recv_port,str(key))
    result = udpcli.send_msg(cmd, send_host, int(port))
    return result.split('\n')
def get_vpn_all_account_process():
    all_users = SCFUtil.get_all_sysusers()
    users_cindir = SCFUtil.get_account(all_users)
    dir={}
    for i in users_cindir.keys():
        if i == "bep":
            file = users_cindir[i]+"/etc/service.bin"
            if os.path.exists(file):
                cmd = "cat %s" % file
                status, out = commands.getstatusoutput(cmd)
                if not status and out:
                    for j in out.split('\n'):
                        if re.search(' '+service_type+' ',j):
                            key = j.split()[1]
                            process_list = SCFUtil.get_vpn_account_process(i, users_cindir[i])
                            if process_list:
                                port = process_list[0][1]
                                dir[key]='port'
    return get_values(port,key)

def jtl():
    a=0
    b=0
    c=float(0)
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('ccdir_timer_init', j):
            a += int(j.split(' ')[-1])
        if re.search('Anlyzd3_Send', j):
            b += int(j.split(' ')[-1])
        if re.search('Start1', j):
            c += int(j.split(' ')[-1])
    if c == 0:
        print float(0)
    else:
        connect_sucess_rate = "%.2f" % ((a-b)/c*100)
        print connect_sucess_rate
def ydl():
    a=0
    b=0
    c=float(0)
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('oAnswer2', j):
            a += int(j.split(' ')[-1])
        if re.search('tAnswer2', j):
            b += int(j.split(' ')[-1])
        if re.search('Start1', j):
            c += int(j.split(' ')[-1])
    if c == 0:
        print float(0)
    else:
        connect_sucess_rate = "%.2f" % ((a+b)/c*100)
        print connect_sucess_rate
            
def MOsh():
    MO_try_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('getOrreqPara', j):
            MO_try_time += int(j.split(' ')[-1])
    print MO_try_time
def MTsh():
    MT_try_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('getAnlyzdPara', j):
            MT_try_time += int(j.split(' ')[-1])
    print MT_try_time
def MOjx():
    MO_connect_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('oAnlyzd2_msg', j):
            MO_connect_time += int(j.split(' ')[-1])
    print MO_connect_time
def MTjx():
    MT_connect_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('Anlyzd2_CheckTchang', j):
            MT_connect_time += int(j.split(' ')[-1])
    print MT_connect_time
def MOyd():
    MO_connect_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('oAnswer2', j):
            MO_connect_time += int(j.split(' ')[-1])
    print MO_connect_time
def MTyd():
    MT_connect_time = 0
    result = get_vpn_all_account_process()
    for j in result:
        if re.search('tAnswer2', j):
            MT_connect_time += int(j.split(' ')[-1])
    print MT_connect_time

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print 'parameter error'
        sys.exit()
    func = sys.argv[1]

    if func == 'jtl':
        jtl()
    elif func == 'ydl':
        ydl()
    elif func == 'MOsh':
        MOsh()
    elif func == 'MTsh':
        MTsh()
    elif func == 'MOjx':
        MOjx()
    elif func == 'MTjx':
        MTjx()
    elif func == 'MOyd':
        MOyd()
    elif func == 'MTyd':
        MTyd()
