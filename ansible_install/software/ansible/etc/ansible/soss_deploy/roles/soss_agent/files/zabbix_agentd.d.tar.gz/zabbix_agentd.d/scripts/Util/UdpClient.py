#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/15 10:50
import socket
import os
__all__ = [
    "get_available_port",
    "UdpClient"
]
def get_available_port():
    import random
    cmd = "netstat -ntl |grep -v Active| grep -v Proto|awk '{print $4}'|awk -F: '{print $NF}'"
    ports = os.popen(cmd).read()
    port_list = ports.split('\n')
    t = random.randint(10000, 20000)  # rand available udp port
    if t not in port_list:
        return t
    else:
        get_available_port()
    pass
class UdpClient(object):
    # def __init__(self, host=bind_address['host'], port=bind_address['port']):
    def __init__(self, host='127.0.0.1', port='9999'):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.sock.settimeout(3)
        address = (host, int(port))
        self.sock.bind(address)
    def send_msg(self, data, host='127.0.0.1', port=1025):
        self.sock.sendto(data, (host, port))
        try:
            data, client = self.sock.recvfrom(10240)
            return data
        except Exception as e:
            return ''
    def __del__(self):
        self.sock.close()
