#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 14:07
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import SCFUtil
import json
def get_scf_users():
    all_users = SCFUtil.get_all_sysusers()
    users_cindir = SCFUtil.get_account(all_users)
    ret = {}
    data = []
    for i in users_cindir.keys():
        if i in ["fep","bep"]:
            process_list = SCFUtil.get_scf_account_process(i, users_cindir[i])
            if len(process_list)==0:
                continue
            if process_list[0]:
                    account = {}
                    account['{#ACCOUNT_SCF}'] = i
                    
                    data.append(account)
    ret['data'] = data
    return json.dumps(ret)
if __name__ == '__main__':
    ret = get_scf_users()
    print ret
