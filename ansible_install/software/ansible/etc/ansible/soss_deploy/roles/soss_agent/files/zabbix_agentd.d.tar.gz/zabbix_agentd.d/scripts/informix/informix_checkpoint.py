# -*- coding: UTF-8 -*-
#/usr/bin/python
'''
@author: Administrator
'''
import os
import re
import sys
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import StringUtil
user = sys.argv[1]
def parse():
    cmd = "su - %s -c 'onstat -m'" % user
    p = os.popen(cmd)
    content = p.read()
    checkpointList = StringUtil.getRegValue(
        content, r'.*Checkpoint.*Completed.*seconds.$')
    checkpointTime = 0
    for line in checkpointList:
        match = re.match(r'.*was\s+(\d+)\s+seconds', line)
        time = 0
        if match:
            time = int(match.group(1))
        if time > 0:
            checkpointTime = time
            break
    print checkpointTime
parse()
