#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Auth : mjrao
# @Time : 2017/8/14 16:08
import re
import sys
import os
sys.path.append("/etc/zabbix/zabbix_agentd.d/scripts/")
from Util import UdpClient,SCFUtil
global_host = '0.0.0.0'
global_port = UdpClient.get_available_port()
def get_st_load(port):
    udpcli = UdpClient.UdpClient(global_host, global_port)
    send_host = global_host  # bind_address['host']
    recv_port = global_port  # bind_address['port']
    cmd = '%s ines source all' % recv_port
    result = udpcli.send_msg(cmd, send_host, int(port)).replace('\t','')
    list = result.split('\n')
    total = float(list[6][7:-8])
    used =  float(list[8][6:-7])
    cic = used / total*100
	cic = round(used / total*100,2)
    print cic
def get_scf_account_process_load(value):
    port = value[2]
    return get_st_load(port)
    pass
if __name__=="__main__":
    if len(sys.argv) != 3:
        print 'parameter error'
        sys.exit()
    info = sys.argv[1]
    user = sys.argv[2]
    if '/' in info:
        value = info.split('/')
        if len(value) != 2:
            print('paramter format error')
            sys.exit()
        va = []
        va.append(value[0])
        kk = value[1]
        kkl = kk.split(':')
        va[len(va):len(va)] = kkl
        ret = get_scf_account_process_load(va)
        if ret:
            print ret.strip('%')
    pass
