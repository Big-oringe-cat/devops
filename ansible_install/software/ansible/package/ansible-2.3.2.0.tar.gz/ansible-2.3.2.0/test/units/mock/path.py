def mock_unfrackpath_noop(path):
    ''' Do not expand the path '''
    return path
