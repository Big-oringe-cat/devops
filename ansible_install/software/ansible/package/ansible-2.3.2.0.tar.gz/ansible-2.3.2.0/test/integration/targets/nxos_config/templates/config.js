interface Ethernet2/5
   description test description from ansible
   shutdown

