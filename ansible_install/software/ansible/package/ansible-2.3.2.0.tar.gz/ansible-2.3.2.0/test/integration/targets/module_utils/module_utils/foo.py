#!/usr/bin/env python

foo = "FOO FROM foo.py"
