eggs = 'spam8:eggs'
