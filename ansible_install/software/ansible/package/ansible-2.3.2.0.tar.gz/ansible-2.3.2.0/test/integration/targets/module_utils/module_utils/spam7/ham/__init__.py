eggs = 'spam7:eggs'
