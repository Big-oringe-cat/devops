sysv_is_enabled = 'sysv_is_enabled'
