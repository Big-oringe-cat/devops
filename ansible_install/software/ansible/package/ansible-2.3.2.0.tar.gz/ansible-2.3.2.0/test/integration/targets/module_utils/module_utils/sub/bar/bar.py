#!/usr/bin/env python

bar = "BAR FROM sub/bar/bar.py"
