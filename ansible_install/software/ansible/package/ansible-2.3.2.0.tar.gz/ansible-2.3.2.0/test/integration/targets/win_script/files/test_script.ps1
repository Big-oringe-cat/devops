# Test script to make sure the Ansible script module works.
Write-Host "Woohoo! We can run a PowerShell script via Ansible!"
