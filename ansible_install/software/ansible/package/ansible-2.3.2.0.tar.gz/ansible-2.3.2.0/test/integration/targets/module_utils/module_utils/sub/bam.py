#!/usr/bin/env python

bam = "BAM FROM sub/bam.py"
