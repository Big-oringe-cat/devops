data = 'abcdefgh'
