bacon = 'spam6:bacon'
eggs = 'spam6:eggs'
