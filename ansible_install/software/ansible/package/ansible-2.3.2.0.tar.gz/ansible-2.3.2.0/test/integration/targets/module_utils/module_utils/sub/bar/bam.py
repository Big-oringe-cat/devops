#!/usr/bin/env python

bam = "BAM FROM sub/bar/bam.py"
