data = 'spam5:eggs'
