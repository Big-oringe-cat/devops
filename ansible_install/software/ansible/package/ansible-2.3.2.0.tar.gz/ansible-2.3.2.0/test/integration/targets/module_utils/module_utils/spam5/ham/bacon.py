data = 'spam5:bacon'
